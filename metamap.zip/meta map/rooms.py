import json

class RoomManager:
    def __init__(self, path):
        with open(path, encoding="utf-8") as f:
            self.rooms = json.load(f)

    def smart_search(self, text):
        text = text.lower()

        # ключевые слова
        if "директор" in text:
            return self.search("директор")

        if "туалет" in text:
            return self.search("туалет")

        if "лифт" in text:
            return self.search("лифт")

        if "выход" in text:
            return self.search("exit")

        # поиск номера
        import re
        match = re.search(r"\d+", text)
        if match:
            return self.search(match.group())

        return self.search(text)

    def search(self, query):
        query = query.lower()
        return [
            r for r in self.rooms
            if query in r["name"].lower() or query in r["number"]
        ]

    def get_room_at(self, x, y, floor):
        for r in self.rooms:
            if r["floor"] != floor:
                continue

            c = r["coords"]
            if c["x1"] <= x <= c["x2"] and c["y1"] <= y <= c["y2"]:
                return r
        return None

    def get_exit(self):
        for r in self.rooms:
            if r["number"] == "exit":
                return r