import tkinter as tk

from ui import MapUI
from rooms import RoomManager
from map_loader import load_grid
from navigation import astar

rooms = RoomManager("data/rooms.json")

grids = {
    1: load_grid("data/floor1.png"),
    2: load_grid("data/floor2.png"),
    3: load_grid("data/floor3.png"),
    4: load_grid("data/floor4.png"),
    5: load_grid("data/floor5.png"),
    6: load_grid("data/floor6.png"),
    7: load_grid("data/floor7.png"),
}

floors = {
    1: "data/floor1.png",
    2: "data/floor2.png",
    3: "data/floor3.png",
    4: "data/floor4.png",
    5: "data/floor5.png",
    6: "data/floor6.png",
    7: "data/floor7.png",
}

root = tk.Tk()
#root.iconbitmap("data/icon.ico")
root.title("AI Map MVP")
# точки (в пикселях)
STAIRS = [
    ((237, 248, 290, 358), (237, 248, 290, 358)),  # лестница левая
    ((1009, 248, 1065, 358), (1009, 248, 1065, 358)),  # лестница правая
]

ELEVATORS = [
    ((538, 62, 571, 109), (538, 62, 571, 109)),
    ((538, 115, 571, 164), (538, 115, 571, 164)),
]
root.transitions = [
    ((237, 248, 290, 358), 1),
    ((1009, 248, 1065, 358), 1),
    ((538, 62, 571, 109), 1),
    ((538, 115, 571, 164), 1),
]
transitions = STAIRS + ELEVATORS
app = MapUI(
    root,
    floors,
    rooms,
    grids,
    astar
)
root.transitions = transitions
root.mainloop()