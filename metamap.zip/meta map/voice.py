import speech_recognition as sr

def recognize_speech():
    r = sr.Recognizer()

    with sr.Microphone() as source:
        print("Слушаю...")
        r.adjust_for_ambient_noise(source)
        audio = r.listen(source)

    try:
        text = r.recognize_google(audio, language="ru-RU")
        print("Распознано:", text)
        return text.lower()
    except:
        return ""