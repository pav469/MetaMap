import cv2
import numpy as np


def load_grid(path, scale=4):
    img = cv2.imread(path)

    if img is None:
        raise Exception(f"Не удалось загрузить: {path}")

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)


    grid = np.zeros_like(gray)

    grid[gray < 50] = 0      # стены
    grid[(gray >= 50) & (gray < 200)] = 1   # кабинеты (можно проходить сквозь)
    grid[gray >= 200] = 2    # проход


    wall_mask = (grid == 0).astype(np.uint8)

    wall_thickness = 0 # регулирование толщины стен(не работает слишком малые стены)

    kernel = np.ones((wall_thickness*2+1, wall_thickness*2+1), np.uint8)
    expanded_walls = cv2.dilate(wall_mask, kernel)


    grid[expanded_walls == 1] = 0


    return grid[::scale, ::scale]