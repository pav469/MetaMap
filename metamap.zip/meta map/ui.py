import tkinter as tk
from PIL import Image, ImageTk
from voice import recognize_speech


class MapUI:
    def __init__(self, root, floors, room_manager, grids, astar):
        self.root = root
        self.room_manager = room_manager
        self.floors = floors
        self.grids = grids
        self.astar = astar

        self.root.after_idle(self.center_view)

        self.dot_spacing = 12  # расстояние между шариками (px)
        self.dot_size = 4  # размер шарика
        self.dot_color = "blue"

        self.animating = False
        self.animation_index = 0

        self.path_segments = []
        self.floor_plan = []
        self.current_segment = 0

        self.placing_user = False
        self.user_pos = None
        self.selected_room = None

        # ===== UI =====
        frame = tk.Frame(root)
        frame.pack(fill="both", expand=True)

        search_frame = tk.Frame(root)
        search_frame.pack(fill="x")

        self.search_entry = tk.Entry(search_frame)
        self.search_entry.pack(side="left", fill="x", expand=True)

        tk.Button(search_frame, text="🔍", command=self.search).pack(side="left")
        tk.Button(search_frame, text="🎤", command=self.voice_search).pack(side="left")

        self.results_list = tk.Listbox(root, height=5)
        self.results_list.pack(fill="x")
        self.results_list.bind("<<ListboxSelect>>", self.on_select_result)

        self.canvas = tk.Canvas(frame, bg="white")
        self.canvas.pack(fill="both", expand=True)

        # scroll
        self.v_scroll = tk.Scrollbar(frame, orient="vertical", command=self.canvas.yview)
        self.v_scroll.pack(side="right", fill="y")

        self.h_scroll = tk.Scrollbar(root, orient="horizontal", command=self.canvas.xview)
        self.h_scroll.pack(fill="x")

        self.canvas.configure(
            yscrollcommand=self.v_scroll.set,
            xscrollcommand=self.h_scroll.set
        )

        # ===== IMAGES =====
        self.images = {
            f: Image.open(path)
            for f, path in floors.items()
        }


        self.floor = 1
        self.current_img = self.images[self.floor]

        self.tk_img = ImageTk.PhotoImage(self.current_img)
        self.img_obj = self.canvas.create_image(0, 0, anchor="nw", image=self.tk_img)

        self.canvas.config(scrollregion=(0, 0, self.current_img.width, self.current_img.height))

        self.canvas.bind("<Button-1>", self.on_click)

        # ===== INFO CARD =====
        self.info_frame = tk.Frame(root, bg="white", bd=2, relief="raised")
        self.info_frame.place(relx=0.5, rely=1.0, anchor="s", width=400, height=120)

        self.info_label = tk.Label(self.info_frame, justify="left", bg="white")
        self.info_label.pack(fill="both", expand=True)

        # ===== BUTTONS =====
        for f in range(1, 8):
            tk.Button(root, text=f"{f} этаж", command=lambda f=f: self.set_floor(f)).pack(side="left")
        tk.Button(root, text="📍 Я здесь", command=self.toggle_user).pack(side="left")

    # ========================
    # FLOORS
    # ========================

    def center_view(self):
        self.canvas.update_idletasks()

        w = self.current_img.width
        h = self.current_img.height

        cw = self.canvas.winfo_width()
        ch = self.canvas.winfo_height()

        x = (w - cw) / 2
        y = (h - ch) / 2

        self.canvas.xview_moveto(x / w)
        self.canvas.yview_moveto(y / h)

    def set_floor(self, floor):
        self.floor = floor
        self.update_map(self.images[floor])

    def update_map(self, img):
        self.current_img = img
        self.tk_img = ImageTk.PhotoImage(img)
        self.canvas.itemconfig(self.img_obj, image=self.tk_img)
        self.canvas.config(scrollregion=(0, 0, img.width, img.height))


    def get_spaced_points(self, path, scale=4):
        points = [(x * scale, y * scale) for y, x in path]

        if not points:
            return []

        spaced = [points[0]]
        dist_acc = 0

        for i in range(1, len(points)):
            x1, y1 = points[i - 1]
            x2, y2 = points[i]

            dx = x2 - x1
            dy = y2 - y1
            dist = (dx ** 2 + dy ** 2) ** 0.5

            dist_acc += dist

            if dist_acc >= self.dot_spacing:
                spaced.append((x2, y2))
                dist_acc = 0

        return spaced

    # ========================
    # SEARCH
    # ========================
    def search(self):
        query = self.search_entry.get()
        results = self.room_manager.search(query)

        self.results = results
        self.results_list.delete(0, tk.END)

        for r in results:
            self.results_list.insert(tk.END, f'{r["name"]} ({r["number"]})')

    def voice_search(self):
        text = recognize_speech()
        if not text:
            return

        self.search_entry.delete(0, tk.END)
        self.search_entry.insert(0, text)

        results = self.room_manager.smart_search(text)
        self.results = results

        self.results_list.delete(0, tk.END)
        for r in results:
            self.results_list.insert(tk.END, f'{r["name"]} ({r["number"]})')

        if results:
            self.select_room(results[0])

    def on_select_result(self, event):
        if not self.results_list.curselection():
            return

        room = self.results[self.results_list.curselection()[0]]
        self.select_room(room)

    # ========================
    # ROOM
    # ========================
    def select_room(self, room):
        self.canvas.delete("path")
        self.animating = False

        self.selected_room = room
        self.show_room_info(room)

        self.build_path()
        self.start_animation()
        if room["floor"] != self.floor:
            self.set_floor(room["floor"])

    def show_room_info(self, room):
        text = f"{room['name']} ({room['number']})\nЭтаж: {room['floor']}\n\n{room['description']}"
        self.info_label.config(text=text)

    # ========================
    # CLICK
    # ========================
    def draw_user(self):
        if not self.user_pos:
            return

        x, y = self.user_pos

        self.canvas.create_oval(
            x - 6, y - 6, x + 6, y + 6,
            fill="red",
            outline="white",
            width=2,
            tags="user"
        )

    def on_click(self, event):
        x = int(self.canvas.canvasx(event.x))
        y = int(self.canvas.canvasy(event.y))

        if self.placing_user:
            self.user_pos = (x, y)
            self.placing_user = False

            # удаляем старое
            self.canvas.delete("user")
            self.canvas.delete("path")

            # рисуем пользователя
            self.draw_user()

            # если уже выбран кабинет → строим путь
            if self.selected_room:
                self.build_path()
                self.start_animation()

            return

        room = self.room_manager.get_room_at(x, y, self.floor)

        if room:
            self.select_room(room)
        else:
            self.canvas.delete("path")
            self.info_label.config(text="")

    def toggle_user(self):
        if self.user_pos:
            self.user_pos = None
            self.canvas.delete("user")
            self.canvas.delete("path")
        else:
            self.placing_user = True

    # ========================
    # PATH
    # ========================
    def _build_single_path(self, start_px, goal_px, floor):
        scale = 4
        start = (start_px[1] // scale, start_px[0] // scale)
        goal = (goal_px[1] // scale, goal_px[0] // scale)

        grid = self.grids[floor]
        return self.astar(grid, start, goal)

    def build_path(self):
        if not self.selected_room:
            return

        def center(c):
            return ((c["x1"] + c["x2"]) // 2, (c["y1"] + c["y2"]) // 2)

        if self.user_pos:
            start_px = self.user_pos
            start_floor = self.floor
        else:
            start_px = center(self.room_manager.get_exit()["coords"])
            start_floor = 1

        goal_px = center(self.selected_room["coords"])
        goal_floor = self.selected_room["floor"]

        if start_floor == goal_floor:
            self.path_segments = [self._build_single_path(start_px, goal_px, start_floor)]
            self.floor_plan = [start_floor]
            return

        best = None
        best_len = 999999

        for t in self.root.transitions:
            (x1, y1, x2, y2) = t[0]
            node = ((x1+x2)//2, (y1+y2)//2)

            p1 = self._build_single_path(start_px, node, start_floor)
            p2 = self._build_single_path(node, goal_px, goal_floor)

            if len(p1)+len(p2) < best_len:
                best_len = len(p1)+len(p2)
                best = (p1, p2)

        self.path_segments = [best[0], best[1]]
        self.floor_plan = [start_floor, goal_floor]

    # ========================
    # ANIMATION
    # ========================
    def start_animation(self):
        self.canvas.delete("path")
        self.animation_index = 0
        self.current_segment = 0
        self.animating = True
        self.animate_step()

    def animate_step(self):
        if not self.animating:
            return

        path = self.path_segments[self.current_segment]
        spaced = self.get_spaced_points(path)

        if self.animation_index >= len(spaced):
            self.current_segment += 1

            if self.current_segment >= len(self.path_segments):
                return

            self.animation_index = 0
            self.root.after(300, self.animate_step)
            self.canvas.delete("path")
            return

        x, y = spaced[self.animation_index]

        outer_r = self.dot_size + 1  # ⚪ белая обводка
        inner_r = self.dot_size  # 🔵 центр

        # ⚪ белый круг (обводка)
        self.canvas.create_oval(
            x - outer_r, y - outer_r,
            x + outer_r, y + outer_r,
            fill="white",
            outline="",
            tags="path"
        )

        # 🔵 синий круг (центр)
        self.canvas.create_oval(
            x - inner_r, y - inner_r,
            x + inner_r, y + inner_r,
            fill=self.dot_color,
            outline="",
            tags="path"
        )

        self.animation_index += 1
        self.root.after(20, self.animate_step)


    # ========================
    # FADE
    # ========================
    def center_view(self):
        w = self.current_img.width
        h = self.current_img.height

        canvas_w = self.canvas.winfo_width()
        canvas_h = self.canvas.winfo_height()

        # защита от 0 (Tkinter иногда ещё не готов)
        if canvas_w == 1 or canvas_h == 1:
            self.root.after(100, self.center_view)
            return

        x = (w / 2) - (canvas_w / 2)
        y = (h / 2) - (canvas_h / 2)

        self.canvas.xview_moveto(x / w)
        self.canvas.yview_moveto(y / h)
    def fade_transition(self, new_floor):
        self.canvas.delete("path")
        overlay = self.canvas.create_rectangle(
            0, 0, self.current_img.width, self.current_img.height,
            fill="black", stipple="gray50", tags="fade"

        )

        def switch():
            self.floor = new_floor
            self.update_map(self.images[new_floor])
            self.canvas.delete("fade")

        self.root.after(200, switch)